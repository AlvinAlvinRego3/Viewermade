Ronik2.0.exe
A GDI malware
Combatibility: Windows 10+
On other systems it will just show you a special message :)
Yes, I was strongly inspired by other viruses!
The warning window title is from APM 08279+5255
Do NOT run it on a real PC
I am NOT responsible for ANY damages!
It has only 1 warning!
Have fun LOL

NOTE: This virus was specifically made to be showcased on 1.AV (Ne)má talent by Metoděj Ondra
If you understand to it's purposes, you can run it.

Coded by StarLae (a.k.a. metodej_the_coder)